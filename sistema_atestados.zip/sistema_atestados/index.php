<?php
session_start();

// Configurações do banco de dados
$conn = new mysqli("localhost", "root", "", "sistema_atestados");
if ($conn->connect_error) {
    die("Erro ao conectar ao banco de dados: " . $conn->connect_error);
}

// Funções de segurança e validação
function sanitizeInput($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function validarSenha($senha) {
    return strlen($senha) >= 6;
}

// Funções de banco de dados
function buscarEmpresas($conn) {
    $empresas = [];
    $result = $conn->query("SELECT id, nome FROM empresas");
    while ($row = $result->fetch_assoc()) {
        $empresas[] = $row;
    }
    return $empresas;
}

function buscarAtestados($conn, $empresa_id) {
    $atestados = [];
    $stmt = $conn->prepare("SELECT * FROM atestados WHERE empresa_id = ?");
    $stmt->bind_param("i", $empresa_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $atestados[] = $row;
    }
    return $atestados;
}

function buscarTodosAtestados($conn) {
    $atestados = [];
    $result = $conn->query("SELECT * FROM atestados");
    while ($row = $result->fetch_assoc()) {
        $atestados[] = $row;
    }
    return $atestados;
}

function buscarFuncionariosPorEmpresa($conn, $empresa_id) {
    $funcionarios = [];
    $stmt = $conn->prepare("SELECT id, nome FROM funcionarios WHERE empresa_id = ?");
    $stmt->bind_param("i", $empresa_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $funcionarios[] = $row;
    }
    return $funcionarios;
}

// Exportar atestados para CSV
if (isset($_GET['exportar_csv'])) {
    $empresa_id = $_SESSION['empresa_id'];
    $atestados = buscarAtestados($conn, $empresa_id);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="atestados.csv"');

    $output = fopen('php://output', 'w');

    // Cabeçalho do CSV
    fputcsv($output, ['Funcionário', 'Data', 'Status', 'Documento'], ';');

    // Dados do CSV
    foreach ($atestados as $atestado) {
        fputcsv($output, [
            $atestado['funcionario'],
            $atestado['data'],
            $atestado['status'],
            $atestado['documento']
        ], ';');
    }

    fclose($output);
    exit();
}

// Buscar funcionários via AJAX
if (isset($_GET['buscar_funcionarios'])) {
    $empresa_id = $_GET['empresa_id'];
    $funcionarios = buscarFuncionariosPorEmpresa($conn, $empresa_id);
    echo json_encode($funcionarios);
    exit();
}

// Login de Empresa
if (isset($_POST['login_empresa'])) {
    $email = sanitizeInput($_POST['email']);
    $senha = sanitizeInput($_POST['senha']);

    $stmt = $conn->prepare("SELECT * FROM empresas WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $empresa = $result->fetch_assoc();
        if (password_verify($senha, $empresa['senha'])) {
            $_SESSION['empresa_id'] = $empresa['id'];
            $_SESSION['empresa_nome'] = $empresa['nome'];
            $_SESSION['tipo'] = 'empresa';
            header("Location: ?pagina=dashboard");
        } else {
            echo "<script>alert('Senha incorreta!');</script>";
        }
    } else {
        echo "<script>alert('Empresa não encontrada!');</script>";
    }
}

// Login de Admin
if (isset($_POST['login_admin'])) {
    $email = sanitizeInput($_POST['email']);
    $senha = sanitizeInput($_POST['senha']);

    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email = ? AND permissao = 'admin'");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $usuario = $result->fetch_assoc();
        if (password_verify($senha, $usuario['senha'])) {
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['nome'] = $usuario['nome'];
            $_SESSION['permissao'] = $usuario['permissao'];
            $_SESSION['tipo'] = 'admin';
            header("Location: ?pagina=dashboard");
        } else {
            echo "<script>alert('Senha incorreta!');</script>";
        }
    } else {
        echo "<script>alert('Admin não encontrado!');</script>";
    }
}

// Cadastro de Empresa (somente admin)
if (isset($_POST['cadastro_empresa']) && $_SESSION['permissao'] === 'admin') {
    $nome = sanitizeInput($_POST['nome']);
    $email = sanitizeInput($_POST['email']);
    $senha = sanitizeInput($_POST['senha']);

    if (!validarEmail($email)) {
        echo "<script>alert('E-mail inválido!');</script>";
    } elseif (!validarSenha($senha)) {
        echo "<script>alert('Senha deve ter pelo menos 6 caracteres!');</script>";
    } else {
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO empresas (nome, email, senha) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $nome, $email, $senha_hash);
        $stmt->execute();
        echo "<script>alert('Empresa cadastrada com sucesso!');</script>";
    }
}

// Cadastro de Atestado
if (isset($_POST['novo_atestado'])) {
    $empresa_id = sanitizeInput($_POST['empresa_id']);
    $funcionario = sanitizeInput($_POST['funcionario']);
    $data = sanitizeInput($_POST['data']);

    if (empty($funcionario) || empty($data) || empty($empresa_id)) {
        echo "<script>alert('Preencha todos os campos!');</script>";
    } else {
        $documento = null;
        if (isset($_FILES['documento']) && $_FILES['documento']['error'] === UPLOAD_ERR_OK) {
            if (!is_dir('uploads')) {
                mkdir('uploads', 0777, true);
            }
            $nomeArquivo = uniqid() . '_' . basename($_FILES['documento']['name']);
            $documento = 'uploads/' . $nomeArquivo;

            if (move_uploaded_file($_FILES['documento']['tmp_name'], $documento)) {
                echo "<script>alert('Arquivo enviado com sucesso!');</script>";
            } else {
                echo "<script>alert('Erro ao enviar o arquivo!');</script>";
                $documento = null;
            }
        }

        if ($documento) {
            $stmt = $conn->prepare("INSERT INTO atestados (empresa_id, funcionario, data, documento, status) VALUES (?, ?, ?, ?, 'Pendente')");
            $stmt->bind_param("isss", $empresa_id, $funcionario, $data, $documento);
            $stmt->execute();
            echo "<script>alert('Atestado cadastrado!');</script>";
        }
    }
}

// Alterar status do funcionário
if (isset($_POST['alterar_status'])) {
    $atestado_id = sanitizeInput($_POST['atestado_id']);
    $status = sanitizeInput($_POST['status']);

    $stmt = $conn->prepare("UPDATE atestados SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $atestado_id);
    $stmt->execute();
    echo "<script>alert('Status atualizado com sucesso!');</script>";
}

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: ?");
}

// Buscar empresas para exibir no formulário
$empresas = buscarEmpresas($conn);

// Buscar atestados da empresa logada (se for uma empresa)
$atestados = [];
if (isset($_SESSION['tipo']) && $_SESSION['tipo'] === 'empresa') {
    $empresa_id = $_SESSION['empresa_id'];
    $atestados = buscarAtestados($conn, $empresa_id);
}

// Buscar todos os atestados (para o admin)
$todosAtestados = [];
if (isset($_SESSION['tipo']) && $_SESSION['tipo'] === 'admin') {
    $todosAtestados = buscarTodosAtestados($conn);
}

// Definir a página atual
$pagina = isset($_GET['pagina']) ? $_GET['pagina'] : 'login';
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Veracidade de Atestados</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .navbar-custom {
            background-color: #007bff;
        }
        .navbar-custom .navbar-brand, .navbar-custom .nav-link {
            color: #fff !important;
        }
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
        }
        @media (max-width: 768px) {
            .navbar-brand {
                font-size: 1.2rem; /* Tamanho menor para telas pequenas */
            }
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .btn-custom {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
        .table-custom {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .alert-custom {
            border-radius: 10px;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const empresaSelect = document.querySelector('select[name="empresa_id"]');
            const funcionarioSelect = document.querySelector('select[name="atestado_id"]');

            empresaSelect.addEventListener('change', function() {
                const empresaId = this.value;
                funcionarioSelect.innerHTML = '<option value="">Selecione um funcionário</option>';

                if (empresaId) {
                    fetch(`?buscar_funcionarios&empresa_id=${empresaId}`)
                        .then(response => response.json())
                        .then(data => {
                            data.forEach(funcionario => {
                                const option = document.createElement('option');
                                option.value = funcionario.id;
                                option.textContent = funcionario.nome;
                                funcionarioSelect.appendChild(option);
                            });
                        })
                        .catch(error => console.error('Erro ao buscar funcionários:', error));
                }
            });
        });
    </script>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container-fluid">
            <!-- Centralizando o texto no navbar -->
            <a class="navbar-brand mx-auto" href="#">Sistema de veracidade de atestados</a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['tipo'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="?logout">Sair</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <!-- Logo da OnCare -->
        <div class="text-center mb-4">
            <img src="https://oncaresaude.com.br/wp-content/uploads/2023/08/logo-oncare-site.png" alt="Logo OnCare" style="width: 200px;">
        </div>

        <?php if ($pagina === 'login'): ?>
            <!-- Formulário de Login para Empresas -->
            <div class="row justify-content-center mb-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header text-center">
                            <h2>Login Empresa</h2>
                        </div>
                        <div class="card-body">
                            <form method="post">
                                <div class="mb-3">
                                    <label for="email" class="form-label">E-mail</label>
                                    <input type="email" name="email" class="form-control" placeholder="E-mail" required>
                                </div>
                                <div class="mb-3">
                                    <label for="senha" class="form-label">Senha</label>
                                    <input type="password" name="senha" class="form-control" placeholder="Senha" required>
                                </div>
                                <button type="submit" name="login_empresa" class="btn btn-custom w-100">Entrar como Empresa</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Formulário de Login para Admin -->
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header text-center">
                            <h2>Login Admin</h2>
                        </div>
                        <div class="card-body">
                            <form method="post">
                                <div class="mb-3">
                                    <label for="email" class="form-label">E-mail</label>
                                    <input type="email" name="email" class="form-control" placeholder="E-mail" required>
                                </div>
                                <div class="mb-3">
                                    <label for="senha" class="form-label">Senha</label>
                                    <input type="password" name="senha" class="form-control" placeholder="Senha" required>
                                </div>
                                <button type="submit" name="login_admin" class="btn btn-custom w-100">Entrar como Admin</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php elseif ($pagina === 'dashboard'): ?>
            <!-- Painel do Admin/Empresa -->
            <h2 class="text-center">Bem-vindo, <?php echo htmlspecialchars($_SESSION['tipo'] === 'empresa' ? $_SESSION['empresa_nome'] : $_SESSION['nome']); ?>!</h2>
            <div class="text-center mt-3">
                <a class="btn btn-danger" href="?logout">Sair</a>
                <a class="btn btn-success" href="https://wa.me/5511915280004?text=Olá,%20gostaria%20de%20falar%20com%20o%20responsável%20do%20setor%20sobre%20veracidade." target="_blank">
                    <i class="fab fa-whatsapp"></i> Falar com o Responsável
                </a>
            </div>

            <!-- Funcionalidades específicas para empresas e admin -->
            <?php if ($_SESSION['tipo'] === 'empresa'): ?>
                <!-- Área da Empresa -->
                <div class="mt-4">
                    <h3>Área da Empresa</h3>
                    <p>Aqui você pode acompanhar as veracidades.</p>

                    <!-- Área de Avisos -->
                    <div class="alert alert-warning alert-custom">
                        <h4><i class="fas fa-exclamation-circle"></i> Avisos Importantes</h4>
                        <ul>
                            <?php
                            $atestadosPendentes = array_filter($atestados, function($atestado) {
                                return $atestado['status'] === 'Pendente';
                            });

                            if (count($atestadosPendentes) > 0) {
                                echo "<li>Você tem <strong>" . count($atestadosPendentes) . "</strong> atestado(s) pendente(s).</li>";
                            } else {
                                echo "<li>Não há atestados pendentes.</li>";
                            }
                            ?>
                            <li>Verifique os prazos de envio de documentos.</li>
                            <li>Mantenha os dados dos funcionários atualizados.</li>
                        </ul>
                    </div>

                    <!-- Botão para exportar atestados em CSV -->
                    <a class="btn btn-custom mb-4" href="?exportar_csv"><i class="fas fa-file-export"></i> Exportar Atestados (CSV)</a>

                    <!-- Gráfico de Atestados da Empresa -->
                    <h3>Gráfico de veracidade de Atestados</h3>
                    <canvas id="graficoAtestadosEmpresa"></canvas>
                    <script>
                        const ctxEmpresa = document.getElementById('graficoAtestadosEmpresa').getContext('2d');
                        const graficoAtestadosEmpresa = new Chart(ctxEmpresa, {
                            type: 'bar',
                            data: {
                                labels: ['Pendente', 'Em Andamento', 'Aguardando resposta da instituição', 'Atestado verídico', 'Finalizado'],
                                datasets: [{
                                    label: 'Quantidade de Atestados',
                                    data: [
                                        <?php
                                        $pendente = 0;
                                        $em_andamento = 0;
                                        $aguardando = 0;
                                        $veridico = 0;
                                        $finalizado = 0;
                                        foreach ($atestados as $atestado) {
                                            if ($atestado['status'] === 'Pendente') $pendente++;
                                            elseif ($atestado['status'] === 'Em Andamento') $em_andamento++;
                                            elseif ($atestado['status'] === 'Aguardando resposta da instituição') $aguardando++;
                                            elseif ($atestado['status'] === 'Atestado verídico') $veridico++;
                                            elseif ($atestado['status'] === 'Finalizado') $finalizado++;
                                        }
                                        echo "$pendente, $em_andamento, $aguardando, $veridico, $finalizado";
                                        ?>
                                    ],
                                    backgroundColor: [
                                        'rgba(255, 99, 132, 0.2)',
                                        'rgba(54, 162, 235, 0.2)',
                                        'rgba(255, 206, 86, 0.2)',
                                        'rgba(75, 192, 192, 0.2)',
                                        'rgba(153, 102, 255, 0.2)'
                                    ],
                                    borderColor: [
                                        'rgba(255, 99, 132, 1)',
                                        'rgba(54, 162, 235, 1)',
                                        'rgba(255, 206, 86, 1)',
                                        'rgba(75, 192, 192, 1)',
                                        'rgba(153, 102, 255, 1)'
                                    ],
                                    borderWidth: 1
                                }]
                            },
                            options: {
                                scales: {
                                    y: {
                                        beginAtZero: true
                                    }
                                }
                            }
                        });
                    </script>

                    <!-- Lista de Atestados -->
                    <h3 class="mt-4">Veracidade de Atestados</h3>
                    <div class="table-responsive">
                        <table class="table table-striped table-custom">
                            <thead>
                                <tr>
                                    <th>Funcionário</th>
                                    <th>Data</th>
                                    <th>Status</th>
                                    <th>Documento</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($atestados as $atestado): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($atestado['funcionario']); ?></td>
                                        <td><?php echo htmlspecialchars($atestado['data']); ?></td>
                                        <td><?php echo htmlspecialchars($atestado['status']); ?></td>
                                        <td>
                                            <?php if (!empty($atestado['documento'])): ?>
                                                <a href="<?php echo htmlspecialchars($atestado['documento']); ?>" target="_blank">Ver Documento</a>
                                            <?php else: ?>
                                                Nenhum documento
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php else: ?>
                <!-- Área do Admin -->
                <h3 class="mt-4">Área do Admin</h3>
                <p>Aqui você pode cadastrar empresas e atestados.</p>

                <!-- Gráfico de Atestados -->
                <h3>Gráfico de Atestados</h3>
                <canvas id="graficoAtestados"></canvas>
                <script>
                    const ctx = document.getElementById('graficoAtestados').getContext('2d');
                    const graficoAtestados = new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: ['Pendente', 'Em Andamento', 'Aguardando resposta da instituição', 'Atestado verídico', 'Finalizado'],
                            datasets: [{
                                label: 'Quantidade de Atestados',
                                data: [
                                    <?php
                                    $pendente = 0;
                                    $em_andamento = 0;
                                    $aguardando = 0;
                                    $veridico = 0;
                                    $finalizado = 0;
                                    foreach ($todosAtestados as $atestado) {
                                        if ($atestado['status'] === 'Pendente') $pendente++;
                                        elseif ($atestado['status'] === 'Em Andamento') $em_andamento++;
                                        elseif ($atestado['status'] === 'Aguardando resposta da instituição') $aguardando++;
                                        elseif ($atestado['status'] === 'Atestado verídico') $veridico++;
                                        elseif ($atestado['status'] === 'Finalizado') $finalizado++;
                                    }
                                    echo "$pendente, $em_andamento, $aguardando, $veridico, $finalizado";
                                    ?>
                                ],
                                backgroundColor: [
                                    'rgba(255, 99, 132, 0.2)',
                                    'rgba(54, 162, 235, 0.2)',
                                    'rgba(255, 206, 86, 0.2)',
                                    'rgba(75, 192, 192, 0.2)',
                                    'rgba(153, 102, 255, 0.2)'
                                ],
                                borderColor: [
                                    'rgba(255, 99, 132, 1)',
                                    'rgba(54, 162, 235, 1)',
                                    'rgba(255, 206, 86, 1)',
                                    'rgba(75, 192, 192, 1)',
                                    'rgba(153, 102, 255, 1)'
                                ],
                                borderWidth: 1
                            }]
                        },
                        options: {
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                </script>

                <!-- Cadastro de Empresa -->
                <h3 class="mt-4">Cadastrar Nova Empresa</h3>
                <form method="post">
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome da Empresa</label>
                        <input type="text" name="nome" class="form-control" placeholder="Nome da Empresa" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">E-mail</label>
                        <input type="email" name="email" class="form-control" placeholder="E-mail" required>
                    </div>
                    <div class="mb-3">
                        <label for="senha" class="form-label">Senha</label>
                        <input type="password" name="senha" class="form-control" placeholder="Senha" required>
                    </div>
                    <button type="submit" name="cadastro_empresa" class="btn btn-custom">Cadastrar Empresa</button>
                </form>

                <!-- Cadastro de Atestado -->
                <h3 class="mt-4">Cadastrar Atestado</h3>
                <form method="post" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="empresa_id" class="form-label">Empresa</label>
                        <select name="empresa_id" class="form-control" required>
                            <option value="">Selecione uma empresa</option>
                            <?php foreach ($empresas as $empresa): ?>
                                <option value="<?php echo $empresa['id']; ?>"><?php echo htmlspecialchars($empresa['nome']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="funcionario" class="form-label">Nome do Funcionário</label>
                        <input type="text" name="funcionario" class="form-control" placeholder="Nome do Funcionário" required>
                    </div>
                    <div class="mb-3">
                        <label for="data" class="form-label">Data</label>
                        <input type="date" name="data" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="documento" class="form-label">Documento</label>
                        <input type="file" name="documento" class="form-control">
                    </div>
                    <button type="submit" name="novo_atestado" class="btn btn-custom">Cadastrar</button>
                </form>

                <!-- Alterar Status do Funcionário -->
                <h3 class="mt-4">Alterar Status do Funcionário</h3>
                <form method="post">
                    <div class="mb-3">
                        <label for="empresa_id" class="form-label">Empresa</label>
                        <select name="empresa_id" class="form-control" required>
                            <option value="">Selecione uma empresa</option>
                            <?php foreach ($empresas as $empresa): ?>
                                <option value="<?php echo $empresa['id']; ?>"><?php echo htmlspecialchars($empresa['nome']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="atestado_id" class="form-label">Funcionário</label>
                        <select name="atestado_id" class="form-control" required>
                            <option value="">Selecione um funcionário</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" class="form-control" required>
                            <option value="Pendente">Pendente</option>
                            <option value="Em Andamento">Em Andamento</option>
                            <option value="Aguardando resposta da instituição">Aguardando resposta da instituição</option>
                            <option value="Atestado verídico">Atestado verídico</option>
                            <option value="Finalizado">Finalizado</option>
                        </select>
                    </div>
                    <button type="submit" name="alterar_status" class="btn btn-custom">Alterar Status</button>
                </form>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>